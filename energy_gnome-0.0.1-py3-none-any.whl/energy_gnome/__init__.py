from energy_gnome import config  # noqa: F401
