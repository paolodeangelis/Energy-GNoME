from pathlib import Path  # noqa: F401

from loguru import logger  # noqa: F401
from tqdm import tqdm  # noqa: F401


def get_superconductors():
    # PLACEHOLDER
    pass
